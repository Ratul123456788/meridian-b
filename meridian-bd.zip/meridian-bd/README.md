# Meridian Electronics: Bangladesh store

Node.js + SQLite store with real cart, checkout, COD, bKash, Nagad, admin dashboard and a persistent database.

## 1. What you need to buy or register
| Item | Why | Typical cost |
|---|---|---|
| Domain (.com.bd via BTCL-approved registrars, or .com) | Your web address | ৳1,000–2,500/yr |
| VPS or app host (Node 18+, persistent disk) | Runs server and database | ~$5–6/month (DigitalOcean, Hetzner, Railway, Render with disk) |
| bKash merchant account (Tokenized Checkout) | Gives App Key, App Secret, Username, Password | Via bKash merchant onboarding; needs trade licence, TIN, bank account |
| Nagad merchant account | Gives Merchant ID, merchant private key, Nagad public key | Via Nagad merchant onboarding; same documents |
| Trade licence + TIN | Required by both wallets and for lawful trading | Your business |

Payment credentials are issued only by bKash and Nagad after they approve your business. Start with their **sandbox** credentials, test, then switch the URLs in `.env` to production.

## 2. Run locally
```
npm install
cp .env.example .env     # fill in JWT_SECRET, ADMIN_PASSWORD
npm start                # http://localhost:3000
```
Admin: open `/#admin`, sign in, add your first products. Cash on delivery works immediately; bKash and Nagad work once their credentials are in `.env`.

## 3. Deploy to a VPS (Ubuntu) with your domain
1. Point the domain's A record to the server IP.
2. Install Node 18+, copy this folder, run `npm install --omit=dev`, create `.env` with `BASE_URL=https://yourdomain`.
3. Keep it running: `npm i -g pm2 && pm2 start server.js --name meridian && pm2 save && pm2 startup`.
4. Install Nginx as reverse proxy to `localhost:3000`, then HTTPS: `sudo certbot --nginx -d yourdomain -d www.yourdomain`.
5. HTTPS is mandatory: bKash and Nagad callbacks and the secure admin cookie need it.

## 4. Backups (important)
All data is one file: `data/meridian.db`. Back it up daily (`sqlite3 data/meridian.db ".backup backup.db"` via cron, copied off the server).

## 5. Before going live
- Test every payment path in sandbox: success, cancel, failure. Failed or cancelled payments cancel the order and return stock automatically.
- Nagad: the signing and encryption flow is implemented from Nagad's public documentation; verify it against your sandbox credentials and Nagad's current API version, and adjust headers if their integration team asks.
- Set `DELIVERY_DHAKA`, `DELIVERY_OUTSIDE`. The delivery figures shown at checkout (৳70 / ৳130) are display text in `public/app.js`; change them to match.
- Replace the footer contact placeholders in `public/app.js`.
- Prices are VAT-inclusive (no separate VAT line). Confirm your VAT and invoicing obligations with an accountant.
- Add Terms, Privacy and Return Policy pages (required by payment providers).
- Change the admin password regularly. Login is rate-limited and uses an HttpOnly cookie.
